package com.suaraku.app

import android.content.Intent
import android.media.MediaPlayer
import android.provider.DocumentsContract
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun Pick(text: String, selected: Boolean, onClick: () -> Unit) {
    val pad = PaddingValues(horizontal = 14.dp)
    if (selected) Button(onClick = onClick, contentPadding = pad) { Text(text, maxLines = 1) }
    else FilledTonalButton(onClick = onClick, contentPadding = pad) { Text(text, maxLines = 1) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("Belum ada file") }
    var ci by remember { mutableStateOf(0) }
    var si by remember { mutableStateOf(0) }
    var fmt by remember { mutableStateOf(OutFmt.M4A) }
    var srcSel by remember { mutableStateOf(0) }
    var nrSel by remember { mutableStateOf(0) }
    var brSel by remember { mutableStateOf(0) }
    val prefs = remember { ctx.getSharedPreferences("suaraku", 0) }
    var folder by remember { mutableStateOf(prefs.getString("folder", null)?.let { Uri.parse(it) }) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<File?>(null) }
    var resultFmt by remember { mutableStateOf(OutFmt.M4A) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }

    DisposableEffect(Unit) { onDispose { player?.release() } }
    DisposableEffect(busy) {
        view.keepScreenOn = busy
        onDispose { view.keepScreenOn = false }
    }

    fun stopPlayer() { player?.release(); player = null; playing = false }
    fun resetResult() { stopPlayer(); result = null }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            uri = u; resetResult(); status = ""
            var name = "audio"
            ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i)
                }
            }
            val d = try { AudioDecoder.durationMs(ctx, u) } catch (_: Throwable) { 0L }
            fileName = "$name  (${d / 60000}:${(d / 1000 % 60).toString().padStart(2, '0')})"
            if (d > VoiceEngine.MAX_MS + 3000) status = "Durasi lebih dari 10 menit, tidak bisa diproses."
        }
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            ctx.contentResolver.takePersistableUriPermission(
                u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            prefs.edit().putString("folder", u.toString()).apply()
            folder = u
        }
    }
    fun folderLabel(u: Uri): String =
        Uri.decode(DocumentsContract.getTreeDocumentId(u)).replace("primary:", "Penyimpanan internal/")
    fun saveToFolder(f: File, name: String, mime: String): Boolean {
        val tree = folder ?: return false
        return try {
            val dir = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val dst = DocumentsContract.createDocument(ctx.contentResolver, dir, mime, name) ?: return false
            ctx.contentResolver.openOutputStream(dst)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            true
        } catch (t: Throwable) { false }
    }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/*")) { u ->
        val f = result
        if (u != null && f != null) {
            ctx.contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            status = "Tersimpan."
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("SuaraKu", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = { pick.launch(arrayOf("audio/*", "video/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text("Pilih file (.mp3 / .m4a / .mp4, maks 10 menit)")
        }
        Text(fileName)

        Text("Suara sumber", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Otomatis", "Laki-laki", "Perempuan").forEachIndexed { i, t -> Pick(t, i == srcSel) { srcSel = i; resetResult() } }
        }

        Text("Karakter suara", style = MaterialTheme.typography.titleMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            EFFECTS.forEachIndexed { i, e -> Pick(e.name, i == ci) { ci = i; resetResult() } }
        }

        Text("Gaya intonasi", style = MaterialTheme.typography.titleMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            STYLES.forEachIndexed { i, s -> Pick(s.name, i == si) { si = i; resetResult() } }
        }

        Text("Bersihkan noise", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Mati", "Ringan", "Sedang", "Kuat").forEachIndexed { i, t -> Pick(t, i == nrSel) { nrSel = i; resetResult() } }
        }

        Text("Kurangi suara napas", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Mati", "Ringan", "Sedang", "Kuat").forEachIndexed { i, t -> Pick(t, i == brSel) { brSel = i; resetResult() } }
        }

        Text("Folder simpan", style = MaterialTheme.typography.titleMedium)
        Text(folder?.let { folderLabel(it) } ?: "Belum dipilih (akan ditanya saat menyimpan)")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pick("Pilih folder", false) { pickFolder.launch(null) }
            if (folder != null) Pick("Hapus pilihan", false) { prefs.edit().remove("folder").apply(); folder = null }
        }

        Text("Format hasil", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutFmt.values().forEach { f -> Pick(f.label, f == fmt) { fmt = f; resetResult() } }
        }

        if (status.isNotEmpty()) Text(status)
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())

        if (busy) {
            OutlinedButton(onClick = { job?.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("Batal") }
        } else {
            Button(
                enabled = uri != null,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val u = uri ?: return@Button
                    busy = true; stopPlayer(); result = null
                    job = scope.launch {
                        try {
                            val out = File(ctx.cacheDir, "hasil.${fmt.ext}")
                            val chosen = fmt
                            val info = withContext(Dispatchers.Default) {
                                VoiceEngine.run(ctx, u, EFFECTS[ci], STYLES[si], chosen, srcSel, nrSel, brSel, out, { ensureActive() }, { status = it })
                            }
                            result = out; resultFmt = chosen
                            status = "Selesai ($info). Tekan Putar untuk preview."
                        } catch (e: CancellationException) {
                            status = "Dibatalkan."
                        } catch (t: Throwable) {
                            status = "Gagal: ${t.message}"
                        } finally { busy = false }
                    }
                }
            ) { Text("Proses") }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                enabled = result != null && !busy,
                modifier = Modifier.weight(1f),
                onClick = {
                    if (playing) stopPlayer() else {
                        player = MediaPlayer().apply {
                            setDataSource(result!!.path); prepare()
                            setOnCompletionListener { playing = false }
                            start()
                        }
                        playing = true
                    }
                }
            ) { Text(if (playing) "Berhenti" else "Putar") }
            OutlinedButton(
                enabled = result != null && !busy,
                modifier = Modifier.weight(1f),
                onClick = {
                    val name = "suaraku_${EFFECTS[ci].name}_${STYLES[si].name}.${resultFmt.ext}".replace(' ', '_')
                    val mime = if (resultFmt == OutFmt.WAV) "audio/x-wav" else "audio/mp4"
                    val f = result
                    if (f != null && folder != null) {
                        status = if (saveToFolder(f, name, mime)) "Tersimpan di: ${folderLabel(folder!!)}"
                        else "Gagal menyimpan ke folder itu. Pilih folder lagi."
                    } else save.launch(name)
                }
            ) { Text("Simpan") }
        }
    }
}
